import { useState, useEffect } from 'react';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { auth, googleProvider } from './firebase';
import './App.css';

// Rakuten Application ID
const RAKUTEN_APP_ID = "YOUR_Rakuten_Application_ID";

function App() {
  const [user, setUser] = useState(null);
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Listen for auth state changes
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    // Only fetch books if user is logged in
    if (!user) {
      setBooks([]);
      return;
    }

    const fetchBooks = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(`https://app.rakuten.co.jp/services/api/BooksBook/Search/20170404?format=json&title=AI&booksGenreId=001005&sort=sales&applicationId=${RAKUTEN_APP_ID}`);

        if (!response.ok) {
          throw new Error(`API Request Failed: ${response.status}`);
        }

        const data = await response.json();

        if (data.error) {
          throw new Error(data.error_description || data.error);
        }

        if (data.Items && data.Items.length > 0) {
          setBooks(data.Items.map(item => item.Item));
        } else {
          setBooks([]);
        }

      } catch (err) {
        console.error("Fetch error:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBooks();
  }, [user]); // Re-run when user changes (logs in)

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed", error);
      setError("ログインに失敗しました。");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>AI Book</h1>
        <p>AIテクノロジーを学ぶための厳選書籍</p>

        {user ? (
          <div className="user-info">
            <p>ようこそ, {user.displayName} さん</p>
            <button onClick={handleLogout} className="auth-button logout">ログアウト</button>
          </div>
        ) : (
          <p className="auth-message">書籍を閲覧するにはログインしてください</p>
        )}
      </header>

      <main>
        {!user ? (
          <div className="login-container">
            <button onClick={handleLogin} className="auth-button login">Googleでログイン</button>
          </div>
        ) : (
          <>
            {loading && <p className="loading">書籍データを読み込み中...</p>}

            {error && (
              <div className="error">
                <p>エラーが発生しました: {error}</p>
              </div>
            )}

            <div className="book-grid">
              {books.map((book, index) => (
                <a href={book.itemUrl} key={book.isbn || index} target="_blank" rel="noopener noreferrer" className="book-card">
                  <div className="book-image-container">
                    {book.largeImageUrl ? (
                      <img src={book.largeImageUrl} alt={book.title} />
                    ) : (
                      <div className="no-image">No Image</div>
                    )}
                  </div>
                  <div className="book-info">
                    <h3>{book.title}</h3>
                    <p className="author">{book.author}</p>
                    <p className="price">¥{book.itemPrice} + 税</p>
                  </div>
                </a>
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

export default App;
