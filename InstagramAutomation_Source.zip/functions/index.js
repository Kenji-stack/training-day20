import { onSchedule } from "firebase-functions/v2/scheduler";
import * as logger from "firebase-functions/logger";
import { initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

initializeApp();
const db = getFirestore();

export const publishScheduledPosts = onSchedule("every 1 minutes", async (event) => {
    logger.info("Checking for scheduled posts...");

    const now = new Date().toISOString();
    // Get posts that are 'pending' and scheduledAt <= now
    const snapshot = await db.collection('posts')
        .where('status', '==', 'pending')
        .where('scheduledAt', '<=', now)
        .get();

    if (snapshot.empty) {
        logger.info("No pending posts found.");
        return;
    }

    logger.info(`Found ${snapshot.size} posts to publish.`);

    const batch = db.batch();

    for (const doc of snapshot.docs) {
        const post = doc.data();
        logger.info(`Processing post ${doc.id} for user ${post.userId}`);

        try {
            // Fetch user settings for credentials
            const settingsSnap = await db.doc(`settings/${post.userId}`).get();
            if (!settingsSnap.exists) {
                logger.error(`No settings found for user ${post.userId}. Mark as failed.`);
                batch.update(doc.ref, { status: 'failed', failureReason: 'No API settings found' });
                continue;
            }

            const { access_token, ig_user_id } = settingsSnap.data();
            if (!access_token || !ig_user_id) {
                logger.error(`Missing token or IG ID for user ${post.userId}.`);
                batch.update(doc.ref, { status: 'failed', failureReason: 'Missing API credentials' });
                continue;
            }

            // TODO: Real Instagram API call here using access_token and ig_user_id
            // const response = await axios.post(...)

            logger.info(`Successfully published (mock) for user ${post.userId}`);

            batch.update(doc.ref, {
                status: 'published',
                publishedAt: new Date().toISOString(),
                instagramPostId: 'mock_ig_id_' + Date.now()
            });

        } catch (error) {
            logger.error(`Failed to publish post ${doc.id}:`, error);
            batch.update(doc.ref, { status: 'failed', failureReason: error.message });
        }
    }

    await batch.commit();
    logger.info("Batch update completed.");
});
