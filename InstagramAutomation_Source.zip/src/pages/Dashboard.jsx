import { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { Plus, LogOut, Loader2, Clock, CheckCircle, AlertCircle, Settings as SettingsIcon, Instagram } from 'lucide-react';

export default function Dashboard() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const user = auth.currentUser;

    useEffect(() => {
        if (!user) return;

        // Simplest query first: just get all posts by user. 
        // Requires composite index for userId + scheduledAt if we sort. 
        // Let's rely on client side sort for small data or simple query for now to avoid index creation block in dev.
        const q = query(
            collection(db, 'posts'),
            where('userId', '==', user.uid)
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const postsData = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            })).sort((a, b) => new Date(b.scheduledAt) - new Date(a.scheduledAt)); // Sort desc
            setPosts(postsData);
            setLoading(false);
        });

        return () => unsubscribe();
    }, [user]);

    const StatusIcon = ({ status }) => {
        switch (status) {
            case 'published': return <CheckCircle className="w-5 h-5 text-green-400" />;
            case 'failed': return <AlertCircle className="w-5 h-5 text-red-400" />;
            default: return <Clock className="w-5 h-5 text-yellow-400" />;
        }
    };

    return (
        <div className="min-h-screen bg-black text-white relative">
            <div className="max-w-4xl mx-auto p-6 pb-24">
                <header className="flex justify-between items-center mb-10">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 rounded-xl shadow-lg shadow-pink-500/20">
                            <Instagram className="w-8 h-8 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-200 via-pink-200 to-purple-200">
                                Instagram Dashboard
                            </h1>
                            <p className="text-gray-400 text-sm mt-1">Welcome back, {user?.displayName}</p>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <button
                            onClick={() => navigate('/settings')}
                            className="p-2 hover:bg-white/10 rounded-full transition text-gray-400 hover:text-white"
                            title="Settings"
                        >
                            <SettingsIcon className="w-6 h-6" />
                        </button>
                        <button
                            onClick={() => auth.signOut()}
                            className="p-2 hover:bg-white/10 rounded-full transition text-gray-400 hover:text-white"
                            title="Logout"
                        >
                            <LogOut className="w-6 h-6" />
                        </button>
                    </div>
                </header>

                {loading ? (
                    <div className="flex justify-center py-20">
                        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
                    </div>
                ) : posts.length === 0 ? (
                    <div className="text-center py-20 text-gray-500 bg-white/5 rounded-3xl border border-white/5">
                        <p>No scheduled posts yet.</p>
                        <p className="text-sm mt-2">Create your first post below!</p>
                    </div>
                ) : (
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {posts.map(post => (
                            <div key={post.id} className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden hover:border-gray-700 transition group">
                                <div className="aspect-square bg-gray-800 relative">
                                    <img src={post.imageUrl} alt="Post" className="w-full h-full object-cover" />
                                    <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded-full flex items-center gap-1 text-xs font-medium">
                                        <StatusIcon status={post.status} />
                                        <span className="capitalize">{post.status}</span>
                                    </div>
                                </div>
                                <div className="p-4">
                                    <p className="text-gray-300 text-sm line-clamp-2 mb-3">{post.caption}</p>
                                    <p className="text-xs text-gray-500 font-mono">
                                        {new Date(post.scheduledAt).toLocaleString()}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* FAB */}
            <button
                onClick={() => navigate('/new-post')}
                className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-tr from-blue-600 to-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-purple-900/40 hover:scale-105 transition-transform group z-50"
            >
                <Plus className="w-8 h-8 text-white group-hover:rotate-90 transition-transform duration-300" />
            </button>
        </div>
    );
}
