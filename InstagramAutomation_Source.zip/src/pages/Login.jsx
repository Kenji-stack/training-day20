import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../lib/firebase';
import { useNavigate } from 'react-router-dom';
import { LogIn } from 'lucide-react';

export default function Login() {
    const navigate = useNavigate();

    const handleLogin = async () => {
        try {
            await signInWithPopup(auth, googleProvider);
            navigate('/');
        } catch (error) {
            console.error('Login failed:', error);
            alert('Login failed. Check console for details. (If using dummy keys, ensure Emulators are running)');
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-900 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900 via-gray-900 to-black text-white relative overflow-hidden">
            {/* Background Elements */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
                <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-purple-600 rounded-full blur-[120px] opacity-20 animate-pulse"></div>
                <div className="absolute top-[30%] right-[10%] w-[30%] h-[30%] bg-blue-600 rounded-full blur-[100px] opacity-20"></div>
            </div>

            <div className="z-10 bg-white/10 backdrop-blur-lg border border-white/20 p-8 rounded-2xl shadow-xl w-full max-w-md flex flex-col items-center space-y-6">
                <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
                    Instagram Automation
                </h1>
                <p className="text-gray-300 text-center">
                    Schedule and manage your posts with antigravity ease.
                </p>

                <button
                    onClick={handleLogin}
                    className="flex items-center justify-center gap-3 w-full py-3 px-6 bg-white/10 hover:bg-white/20 border border-white/10 rounded-xl transition-all duration-300 group"
                >
                    <div className="p-2 bg-white rounded-full group-hover:scale-110 transition-transform">
                        <LogIn className="w-5 h-5 text-gray-900" />
                    </div>
                    <span className="font-semibold">Sign in with Google</span>
                </button>
            </div>
        </div>
    );
}
