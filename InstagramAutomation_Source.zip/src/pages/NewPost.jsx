import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { storage, db, auth } from '../lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ArrowLeft, Upload, Calendar, Send } from 'lucide-react';

export default function NewPost() {
    const navigate = useNavigate();
    const [image, setImage] = useState(null);
    const [imagePreview, setImagePreview] = useState(null);
    const [caption, setCaption] = useState('');
    const [scheduledTime, setScheduledTime] = useState('');
    const [loading, setLoading] = useState(false);

    const handleImageChange = (e) => {
        if (e.target.files[0]) {
            setImage(e.target.files[0]);
            setImagePreview(URL.createObjectURL(e.target.files[0]));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!image || !scheduledTime) return;

        setLoading(true);
        try {
            // 1. Upload Image
            const storageRef = ref(storage, `posts/${auth.currentUser.uid}/${Date.now()}_${image.name}`);
            await uploadBytes(storageRef, image);
            const imageUrl = await getDownloadURL(storageRef);

            // 2. Save to Firestore
            await addDoc(collection(db, 'posts'), {
                userId: auth.currentUser.uid,
                imageUrl,
                caption,
                scheduledAt: new Date(scheduledTime).toISOString(),
                status: 'pending',
                createdAt: serverTimestamp(),
            });

            navigate('/');
        } catch (error) {
            console.error("Error creating post:", error);
            alert("Failed to schedule post");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-black text-white p-6 pb-20">
            <header className="mb-8 flex items-center gap-4">
                <button onClick={() => navigate('/')} className="p-2 hover:bg-white/10 rounded-full transition">
                    <ArrowLeft className="w-6 h-6" />
                </button>
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
                    New Post
                </h1>
            </header>

            <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-6">
                {/* Image Upload */}
                <div className="relative aspect-square w-full bg-gray-900 rounded-2xl border-2 border-dashed border-gray-700 hover:border-blue-500 transition-colors cursor-pointer overflow-hidden group">
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="absolute inset-0 w-full h-full opacity-0 z-10 cursor-pointer"
                    />
                    {imagePreview ? (
                        <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 group-hover:text-blue-400 transition-colors">
                            <Upload className="w-10 h-10 mb-2" />
                            <span className="text-sm font-medium">Click to upload image</span>
                        </div>
                    )}
                </div>

                {/* Caption */}
                <div className="space-y-2">
                    <label className="text-sm text-gray-400 ml-1">Caption</label>
                    <textarea
                        value={caption}
                        onChange={(e) => setCaption(e.target.value)}
                        placeholder="Write a caption..."
                        className="w-full bg-gray-900 border border-gray-800 rounded-xl p-4 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 min-h-[100px] resize-none"
                    />
                </div>

                {/* Schedule */}
                <div className="space-y-2">
                    <label className="text-sm text-gray-400 ml-1 flex items-center gap-2">
                        <Calendar className="w-4 h-4" /> Schedule Time
                    </label>
                    <input
                        type="datetime-local"
                        value={scheduledTime}
                        onChange={(e) => setScheduledTime(e.target.value)}
                        className="w-full bg-gray-900 border border-gray-800 rounded-xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 [&::-webkit-calendar-picker-indicator]:invert"
                    />
                </div>

                <button
                    type="submit"
                    disabled={loading || !image || !scheduledTime}
                    className="w-full py-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl font-bold text-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-purple-900/20"
                >
                    {loading ? 'Scheduling...' : (
                        <>
                            <Send className="w-5 h-5" /> Schedule Post
                        </>
                    )}
                </button>
            </form>
        </div>
    );
}
