import { useState, useEffect } from 'react';
import { db, auth } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Lock } from 'lucide-react';

export default function Settings() {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [token, setToken] = useState('');
    const [igUserId, setIgUserId] = useState('');

    useEffect(() => {
        const fetchSettings = async () => {
            if (!auth.currentUser) return;
            try {
                const docRef = doc(db, 'settings', auth.currentUser.uid);
                const docSnap = await getDoc(docRef);
                if (docSnap.exists()) {
                    const data = docSnap.data();
                    setToken(data.access_token || '');
                    setIgUserId(data.ig_user_id || '');
                }
            } catch (err) {
                console.error("Error fetching settings:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchSettings();
    }, []);

    const handleSave = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await setDoc(doc(db, 'settings', auth.currentUser.uid), {
                access_token: token,
                ig_user_id: igUserId,
                updatedAt: new Date().toISOString()
            }, { merge: true });
            alert('Settings saved!');
        } catch (err) {
            console.error("Error saving settings:", err);
            alert('Failed to save settings.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="min-h-screen bg-black text-white p-6">
            <header className="mb-8 flex items-center gap-4">
                <button onClick={() => navigate('/')} className="p-2 hover:bg-white/10 rounded-full transition">
                    <ArrowLeft className="w-6 h-6" />
                </button>
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
                    Settings
                </h1>
            </header>

            <div className="max-w-md mx-auto bg-gray-900 border border-gray-800 rounded-2xl p-6">
                <form onSubmit={handleSave} className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-sm text-gray-400 flex items-center gap-2">
                            <Lock className="w-4 h-4" /> Instagram Graph API Token
                        </label>
                        <input
                            type="password"
                            value={token}
                            onChange={(e) => setToken(e.target.value)}
                            placeholder="EAA..."
                            className="w-full bg-gray-950 border border-gray-800 rounded-xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono text-sm"
                        />
                        <p className="text-xs text-gray-500">
                            Long-lived access token from Meta Developer Portal.
                        </p>
                    </div>

                    <div className="space-y-2">
                        <label className="text-sm text-gray-400">Instagram Business Account ID</label>
                        <input
                            type="text"
                            value={igUserId}
                            onChange={(e) => setIgUserId(e.target.value)}
                            placeholder="1784..."
                            className="w-full bg-gray-950 border border-gray-800 rounded-xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono text-sm"
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={saving}
                        className="w-full py-3 bg-white text-black rounded-xl font-bold hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
                    >
                        {saving ? 'Saving...' : (
                            <>
                                <Save className="w-5 h-5" /> Save Configuration
                            </>
                        )}
                    </button>
                </form>
            </div>
        </div>
    );
}
