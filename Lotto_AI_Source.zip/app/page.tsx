import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, BarChart2, BrainCircuit, History, Ticket } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 sm:py-32 lg:pb-32 xl:pb-36">
        <div className="container mx-auto px-4 text-center">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/20 rounded-full blur-[100px] -z-10 pointer-events-none" />

          <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
            <span className="block text-primary drop-shadow-[0_0_15px_rgba(var(--primary),0.5)]">
              Win the Lottery
            </span>
            <span className="block mt-2">with AI & Logic</span>
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-lg text-muted-foreground">
            Lotto AI combines statistical analysis, machine learning, and proven theories
            to generate the most probable numbers for Loto 6, Loto 7, and Mini Loto.
          </p>

          <div className="mt-10 flex justify-center gap-4 flex-wrap">
            <Link href="/predict">
              <Button size="lg" className="text-lg px-8 py-6 rounded-full shadow-[0_0_20px_rgba(var(--primary),0.3)] hover:shadow-[0_0_30px_rgba(var(--primary),0.5)] transition-all">
                Start Prediction <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/results">
              <Button variant="outline" size="lg" className="text-lg px-8 py-6 rounded-full backdrop-blur-sm bg-background/50">
                Data Analysis <BarChart2 className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/purchase">
              <Button variant="outline" size="lg" className="text-lg px-8 py-6 rounded-full backdrop-blur-sm bg-background/50">
                Purchase & Tickets <Ticket className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Feature Cards */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-card/50 backdrop-blur border-primary/20 transition-all hover:-translate-y-1 hover:border-primary/50">
              <CardHeader>
                <BrainCircuit className="w-10 h-10 text-primary mb-4" />
                <CardTitle>AI & Theories</CardTitle>
                <CardDescription>
                  Hybrid prediction engine using Deep Learning and 5 classic theories alongside customizable weights.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-card/50 backdrop-blur border-primary/20 transition-all hover:-translate-y-1 hover:border-primary/50">
              <CardHeader>
                <History className="w-10 h-10 text-primary mb-4" />
                <CardTitle>Auto Updates</CardTitle>
                <CardDescription>
                  Always up-to-date with the latest lottery results fetched directly from official sources daily.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-card/50 backdrop-blur border-primary/20 transition-all hover:-translate-y-1 hover:border-primary/50">
              <CardHeader>
                <Ticket className="w-10 h-10 text-primary mb-4" />
                <CardTitle>Ticket Manager</CardTitle>
                <CardDescription>
                  Scan or input your purchased tickets to automatically track winnings and export to spreadsheets.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
