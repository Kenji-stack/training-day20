"use client"

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Sparkles, Brain, Calculator, MessageSquare, ArrowRight } from "lucide-react";

export default function PredictPage() {
    const [loading, setLoading] = useState(false);
    const [prediction, setPrediction] = useState<number[] | null>(null);

    // Theory Weights State
    const [weights, setWeights] = useState({
        hotCold: 50,
        oddEven: 50,
        highLow: 50,
        sum: 50,
        trailing: 50
    });

    const handlePredict = async (method: string) => {
        setLoading(true);
        setPrediction(null);

        // Simulate API call
        setTimeout(() => {
            // Mock prediction based on method
            const mock = Array.from({ length: 6 }, () => Math.floor(Math.random() * 43) + 1).sort((a, b) => a - b);
            setPrediction(mock);
            setLoading(false);
        }, 1500);
    };

    return (
        <div className="container mx-auto py-10 px-4 min-h-screen">
            <div className="max-w-4xl mx-auto space-y-8">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
                        Number Prediction
                    </h1>
                    <p className="text-muted-foreground mt-2">
                        Choose your preferred prediction method.
                    </p>
                </div>

                <Tabs defaultValue="theories" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 h-14 bg-background/50 backdrop-blur border border-border/50">
                        <TabsTrigger value="theories" className="text-lg data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                            <Calculator className="mr-2 h-5 w-5" /> 5 Theories
                        </TabsTrigger>
                        <TabsTrigger value="ai" className="text-lg data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                            <Brain className="mr-2 h-5 w-5" /> AI Standard
                        </TabsTrigger>
                        <TabsTrigger value="chat" className="text-lg data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                            <MessageSquare className="mr-2 h-5 w-5" /> AI Chat
                        </TabsTrigger>
                    </TabsList>

                    {/* 5 Theories Tab */}
                    <TabsContent value="theories" className="mt-8 space-y-6">
                        <Card className="border-primary/20 bg-card/40 backdrop-blur">
                            <CardHeader>
                                <CardTitle>Weighted Logic Analysis</CardTitle>
                                <CardDescription>Adjust the importance of each statistical theory.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-8">
                                {Object.entries(weights).map(([key, val]) => (
                                    <div key={key} className="space-y-4">
                                        <div className="flexjustify-between items-center">
                                            <div className="flex items-center gap-2">
                                                <Badge variant="outline" className="capitalize text-base px-3 py-1">
                                                    {key.replace(/([A-Z])/g, ' $1').trim()} Analysis
                                                </Badge>
                                            </div>
                                            <span className="font-mono text-xl text-primary">{val}%</span>
                                        </div>
                                        <Slider
                                            value={[val]}
                                            max={100}
                                            step={1}
                                            onValueChange={(v) => setWeights({ ...weights, [key]: v[0] })}
                                            className="cursor-pointer"
                                        />
                                    </div>
                                ))}

                                <Button
                                    size="lg"
                                    className="w-full text-lg h-14 mt-4 shadow-lg shadow-primary/20"
                                    onClick={() => handlePredict('theories')}
                                    disabled={loading}
                                >
                                    {loading ? <Loader2 className="animate-spin mr-2" /> : <Sparkles className="mr-2" />}
                                    Generate Prediction
                                </Button>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* AI Standard Tab */}
                    <TabsContent value="ai" className="mt-8 space-y-6">
                        <Card className="border-primary/20 bg-card/40 backdrop-blur">
                            <CardHeader>
                                <CardTitle>AI Statistical Model</CardTitle>
                                <CardDescription>Predicts numbers using weighted decay heatmaps and frequency analysis.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-col items-center justify-center py-8">
                                    <Brain className="w-24 h-24 text-primary/50 mb-6 animate-pulse" />
                                    <p className="text-center max-w-md text-muted-foreground mb-8">
                                        Our AI analyzes historical patterns, applying exponential time-decay to prioritize recent trends while maintaining statistical balance.
                                    </p>

                                    <Button
                                        size="lg"
                                        className="w-full max-w-sm text-lg h-14 shadow-lg shadow-primary/20"
                                        onClick={() => handlePredict('ai')}
                                        disabled={loading}
                                    >
                                        {loading ? <Loader2 className="animate-spin mr-2" /> : <Sparkles className="mr-2" />}
                                        Generate AI Prediction
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* AI Chat Tab */}
                    <TabsContent value="chat" className="mt-8">
                        <Card className="border-primary/20 bg-card/40 backdrop-blur min-h-[500px] flex flex-col">
                            <CardHeader>
                                <CardTitle>AI Lottery Expert</CardTitle>
                                <CardDescription>Ask for advice, lucky numbers, or astrological insights.</CardDescription>
                            </CardHeader>
                            <CardContent className="flex-1 flex flex-col">
                                <ScrollArea className="flex-1 pr-4 mb-4 h-[350px]">
                                    <div className="space-y-4">
                                        <div className="flex justify-start">
                                            <div className="bg-muted px-4 py-2 rounded-lg rounded-tl-none max-w-[80%]">
                                                <p className="text-sm">Hello! I am your Lottery AI Assistant. Ask me anything about Loto 6, 7 or Mini Loto predictions!</p>
                                            </div>
                                        </div>
                                        {/* Mock Chat History for now, real state implementation next */}
                                        <div className="flex justify-end">
                                            <div className="bg-primary px-4 py-2 rounded-lg rounded-tr-none max-w-[80%] text-primary-foreground">
                                                <p className="text-sm">Predict next Loto 6.</p>
                                            </div>
                                        </div>
                                        <div className="flex justify-start">
                                            <div className="bg-muted px-4 py-2 rounded-lg rounded-tl-none max-w-[80%]">
                                                <p className="text-sm">Based on recent data, I suggest focusing on numbers ending in 3. Here is a quick pick: 03, 13, 15, 22, 33, 41.</p>
                                            </div>
                                        </div>
                                    </div>
                                </ScrollArea>
                                <div className="flex gap-2 mt-auto">
                                    <input
                                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                        placeholder="Type your message..."
                                    />
                                    <Button size="icon">
                                        <ArrowRight className="h-4 w-4" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>

                {/* Results Display */}
                {prediction && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <Card className="bg-gradient-to-b from-primary/10 to-background border-primary/50 shadow-[0_0_30px_rgba(var(--primary),0.2)]">
                            <CardHeader className="text-center">
                                <CardTitle className="text-2xl">Predicted Numbers</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex flex-wrap justify-center gap-4 py-6">
                                    {prediction.map((num, i) => (
                                        <div key={i} className="w-16 h-16 rounded-full bg-background border-2 border-primary flex items-center justify-center text-2xl font-bold shadow-[0_0_15px_rgba(var(--primary),0.4)] animate-bounce delay-[${i * 100}ms]">
                                            {num}
                                        </div>
                                    ))}
                                </div>
                                <div className="text-center mt-4">
                                    <Button variant="secondary">Save Prediction</Button>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}
            </div>
        </div>
    );
}
