"use client"

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"; // Note: Need to add select component
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Copy, ExternalLink, Plus, Save, Trash2 } from "lucide-react";

export default function PurchasePage() {
    // Mock State for Purchase List (F-10)
    const [purchaseList, setPurchaseList] = useState([
        { id: 1, type: 'Loto 6', numbers: [3, 15, 22, 28, 33, 41] },
        { id: 2, type: 'Loto 6', numbers: [5, 12, 18, 25, 30, 42] }
    ]);

    const copyToClipboard = (nums: number[]) => {
        navigator.clipboard.writeText(nums.join(','));
        // Could show toast
    };

    return (
        <div className="container mx-auto py-10 px-4 min-h-screen">
            <div className="max-w-5xl mx-auto space-y-8">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
                        Purchase & Manager
                    </h1>
                    <p className="text-muted-foreground mt-2">
                        Manage your tickets and proceed to purchase.
                    </p>
                </div>

                {/* Purchase List (F-10) */}
                <Card className="bg-card/40 backdrop-blur border-primary/20">
                    <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                            <CardTitle>Purchase List (Generated)</CardTitle>
                            <CardDescription>Numbers generated from your predictions pending purchase.</CardDescription>
                        </div>
                        <Button variant="outline" onClick={() => window.open('https://www.takarakuji-official.jp/', '_blank')}>
                            Official Site <ExternalLink className="ml-2 w-4 h-4" />
                        </Button>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Type</TableHead>
                                    <TableHead>Numbers</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {purchaseList.map((item) => (
                                    <TableRow key={item.id}>
                                        <TableCell>
                                            <Badge variant="secondary">{item.type}</Badge>
                                        </TableCell>
                                        <TableCell className="font-mono text-lg font-bold tracking-wider">
                                            {item.numbers.map(n => n.toString().padStart(2, '0')).join(' ')}
                                        </TableCell>
                                        <TableCell className="text-right flex justify-end gap-2">
                                            <Button size="sm" variant="ghost" onClick={() => copyToClipboard(item.numbers)}>
                                                <Copy className="w-4 h-4 mr-2" /> Copy
                                            </Button>
                                            <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                                                <Trash2 className="w-4 h-4" />
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                        <div className="mt-4 p-4 bg-muted/50 rounded-lg text-sm text-muted-foreground border border-border/50">
                            <strong>Note for Auto-Input (F-12):</strong> Due to browser security protections (Cross-Origin), we cannot directly fill the official lottery site form.
                            Please use the <strong>Copy</strong> button above and paste into the official site, or use our helper browser extension (Coming Soon).
                        </div>
                    </CardContent>
                </Card>

                {/* F-2 User Ticket Management */}
                <Card className="bg-card/40 backdrop-blur border-primary/20">
                    <CardHeader>
                        <CardTitle>Register Purchased Ticket</CardTitle>
                        <CardDescription>Manually add tickets you bought to track results.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                            <div className="space-y-2">
                                <label className="text-sm font-medium">Type</label>
                                <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                                    <option>Loto 6</option>
                                    <option>Loto 7</option>
                                    <option>Mini Loto</option>
                                </select>
                            </div>
                            <div className="col-span-2 space-y-2">
                                <label className="text-sm font-medium">Numbers (Calculated/Input)</label>
                                <Input placeholder="01, 02, 03, 04, 05, 06" />
                            </div>
                            <Button>
                                <Save className="mr-2 w-4 h-4" /> Register
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
