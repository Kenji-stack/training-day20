"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

// Mock Data for graphs (F-7)
const sumData = [
    { name: 'Draw 1', sum: 120 },
    { name: 'Draw 2', sum: 135 },
    { name: 'Draw 3', sum: 98 },
    { name: 'Draw 4', sum: 150 },
    { name: 'Draw 5', sum: 142 },
    { name: 'Draw 6', sum: 110 },
    { name: 'Draw 7', sum: 128 },
];

const mockHistory = [
    { id: 1, date: '2023-10-27', type: 'Loto 6', numbers: [3, 15, 22, 28, 33, 41], result: 'Pending', method: 'AI Standard' },
    { id: 2, date: '2023-10-24', type: 'Loto 7', numbers: [1, 5, 9, 14, 21, 22, 30], result: 'Lost', method: '5 Theories' },
    { id: 3, date: '2023-10-20', type: 'Mini Loto', numbers: [2, 10, 11, 24, 30], result: 'Win (5th)', method: 'AI Chat' },
];

export default function ResultsPage() {
    return (
        <div className="container mx-auto py-10 px-4 min-h-screen">
            <div className="max-w-6xl mx-auto space-y-8">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/50 bg-clip-text text-transparent">
                        Analysis & History
                    </h1>
                    <p className="text-muted-foreground mt-2">
                        View past trends and track your prediction performance.
                    </p>
                </div>

                <Tabs defaultValue="graphs" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 h-14 bg-background/50 backdrop-blur border border-border/50">
                        <TabsTrigger value="graphs" className="text-lg">Data Analysis (F-7)</TabsTrigger>
                        <TabsTrigger value="history" className="text-lg">My Predictions (F-8)</TabsTrigger>
                    </TabsList>

                    <TabsContent value="graphs" className="mt-8 space-y-8">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <Card className="bg-card/40 backdrop-blur border-primary/20">
                                <CardHeader>
                                    <CardTitle>Sum Total Trend</CardTitle>
                                    <CardDescription>Movement of the sum of winning numbers.</CardDescription>
                                </CardHeader>
                                <CardContent className="h-[300px]">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <LineChart data={sumData}>
                                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                                            <XAxis dataKey="name" stroke="#888" />
                                            <YAxis stroke="#888" />
                                            <Tooltip contentStyle={{ backgroundColor: '#1f1f1f', border: 'none' }} />
                                            <Line type="monotone" dataKey="sum" stroke="var(--primary)" strokeWidth={3} dot={{ r: 4 }} />
                                        </LineChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>

                            <Card className="bg-card/40 backdrop-blur border-primary/20">
                                <CardHeader>
                                    <CardTitle>Odd/Even Balance</CardTitle>
                                    <CardDescription>Frequency of Odd vs Even numbers in recent draws.</CardDescription>
                                </CardHeader>
                                <CardContent className="h-[300px]">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={[
                                            { name: 'Last 5', Odd: 12, Even: 13 },
                                            { name: 'Last 10', Odd: 25, Even: 25 },
                                            { name: 'Last 20', Odd: 55, Even: 45 },
                                        ]}>
                                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                                            <XAxis dataKey="name" stroke="#888" />
                                            <YAxis stroke="#888" />
                                            <Tooltip contentStyle={{ backgroundColor: '#1f1f1f', border: 'none' }} cursor={{ fill: 'rgba(255,255,255,0.05)' }} />
                                            <Bar dataKey="Odd" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
                                            <Bar dataKey="Even" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="history" className="mt-8">
                        <Card className="bg-card/40 backdrop-blur border-primary/20">
                            <CardHeader>
                                <CardTitle>Prediction History</CardTitle>
                                <CardDescription>Your saved predictions and their outcomes.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <ScrollArea className="h-[500px]">
                                    <div className="space-y-4">
                                        {mockHistory.map((item) => (
                                            <div key={item.id} className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/50 transition-all hover:bg-background/80">
                                                <div className="space-y-1">
                                                    <div className="flex items-center gap-2">
                                                        <Badge variant={item.type === 'Loto 7' ? 'default' : (item.type === 'Loto 6' ? 'secondary' : 'outline')}>
                                                            {item.type}
                                                        </Badge>
                                                        <span className="text-sm text-muted-foreground">{item.date}</span>
                                                    </div>
                                                    <div className="flex gap-2">
                                                        {item.numbers.map(n => (
                                                            <span key={n} className="font-mono font-bold text-lg">{n}</span>
                                                        ))}
                                                    </div>
                                                    <div className="text-xs text-muted-foreground">Method: {item.method}</div>
                                                </div>
                                                <div className="text-right">
                                                    <Badge variant={item.result.includes('Win') ? 'default' : (item.result === 'Pending' ? 'outline' : 'destructive')} className="text-base px-3 py-1">
                                                        {item.result}
                                                    </Badge>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </ScrollArea>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}
