/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const { onRequest, onCall, HttpsError } = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");
const admin = require("firebase-admin");

admin.initializeApp();

// Create and deploy your first functions
// https://firebase.google.com/docs/functions/get-started

const { onSchedule } = require("firebase-functions/v2/scheduler");
const { fetchLatestData } = require("./lib/scraper");
const { predictWithTheories } = require("./lib/theories");
const { predictAI } = require("./lib/ai-model");
const { handleChat } = require("./lib/chat");

// Run every day at 20:00 JST (Draws are Mon/Thu for Loto6, Fri for Loto7, Tue for Mini)
// Cron: "0 20 * * *"
exports.updateLotteryData = onSchedule({
    schedule: "0 20 * * *",
    timeZone: "Asia/Tokyo",
    memory: "1GiB", // Needed for Puppeteer
    timeoutSeconds: 120
}, async (event) => {
    logger.info("Starting scheduled update...");

    // We update all types
    const types = ['loto6', 'loto7', 'miniloto'];
    for (const type of types) {
        try {
            const data = await fetchLatestData(type);
            logger.info(`Fetched ${type}:`, data);
            // Save to Firestore logic here
            // const db = admin.firestore();
            // await db.collection('results').doc(type).collection('history').add(data);
        } catch (e) {
            logger.error(`Failed to update ${type}`, e);
        }
    }
});

exports.predictAI = onCall(async (request) => {
    const type = request.data.type || 'loto6';
    // Mock History
    const history = [];

    try {
        const result = predictAI(history, type);
        return result;
    } catch (e) {
        logger.error("AI Prediction failed", e);
        throw new HttpsError('internal', e.message);
    }
});

exports.chatWithAI = onCall(async (request) => {
    const message = request.data.message;
    const history = request.data.history || [];

    // In production, use process.env.GEMINI_API_KEY
    // For now, we might need to hardcode or use a defineSecret
    const apiKey = process.env.GEMINI_API_KEY || "YOUR_API_KEY_HERE";

    try {
        const reply = await handleChat(message, history, apiKey);
        return { reply };
    } catch (e) {
        logger.error("Chat failed", e);
        throw new HttpsError('internal', "AI is busy or credentials missing.");
    }
});

exports.predictNumbers = onCall(async (request) => {
    // request.data: { type: 'loto6', weights: {...} }
    const type = request.data.type || 'loto6';
    const weights = request.data.weights || {};

    // Logic to fetch history
    const db = admin.firestore();
    // const snapshot = await db.collection('results').doc(type).collection('history').orderBy('date', 'desc').limit(20).get();
    // const history = snapshot.docs.map(d => d.data());
    const history = []; // Mock for now if DB empty

    logger.info(`Predicting for ${type} with weights`, weights);

    try {
        const result = predictWithTheories(history, type, weights);
        return result;
    } catch (e) {
        logger.error("Prediction failed", e);
        throw new HttpsError('internal', e.message);
    }
});

