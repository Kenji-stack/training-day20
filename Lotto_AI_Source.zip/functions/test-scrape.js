const puppeteer = require('puppeteer');

async function testScrape() {
    const url = 'https://www.takarakuji-official.jp/ec/loto6/';
    console.log("Launching browser...");
    const browser = await puppeteer.launch({
        headless: "new"
    });
    const page = await browser.newPage();
    try {
        console.log("Navigating to", url);
        await page.goto(url, { waitUntil: 'networkidle2' });

        console.log("Page Title:", await page.title());

        await page.waitForSelector('body');

        // Improve logging to see if we hit a breakdown
        const text = await page.evaluate(() => document.body.innerText.substring(0, 2000));
        console.log("Body text start:", text.replace(/\s+/g, ' '));

        const possibleIssue = await page.evaluate(() => {
            return document.body.innerText.match(/第\s*\d+\s*回/);
        });
        console.log("Issue match:", possibleIssue);

    } catch (error) {
        console.error("Error:", error.message);
    } finally {
        await browser.close();
    }
}

testScrape();
