export const authPlan = `
# Google Authentication Plan

1.  **Firebase Console Setup (User Action Required)**:
    *   Enable Authentication in Firebase Console.
    *   Enable "Google" sign-in provider.

2.  **Code Implementation**:
    *   Create \`components/auth-provider.tsx\`: React Context to handle user state (user, loading, signIn, signOut).
    *   Create \`components/user-nav.tsx\`: UI component for Login button or User Avatar/Logout menu.
    *   Update \`app/layout.tsx\`: Wrap app with \`AuthProvider\`.
    *   Update \`app/page.tsx\` (and others): Show optional content or redirect if not logged in (optional, or just personalized).
    *   For this app, we will allow guest access but require login for "Saving History" and "Purchase List".

3.  **Deployment**:
    *   Redeploy to Firebase Hosting.
`;
