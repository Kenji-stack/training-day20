import React, { useState, useEffect } from 'react';
import FrequencyButton from './components/FrequencyButton';
import Player from './components/Player';
import Login from './components/Login';
import { FREQUENCIES } from './utils/frequencies';
import { searchVideo } from './utils/youtube';
import { auth, logout } from './utils/auth';
import { onAuthStateChanged } from 'firebase/auth';

// Access API Key from environment variables
const API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;

function App() {
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [currentFrequency, setCurrentFrequency] = useState(null);
  const [videoId, setVideoId] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleFrequencySelect = async (frequency) => {
    if (currentFrequency?.id === frequency.id) {
      // Toggle play/pause if same frequency
      setIsPlaying(!isPlaying);
      return;
    }

    setCurrentFrequency(frequency);
    setIsLoading(true);
    setError(null);

    try {
      if (!API_KEY) {
        throw new Error("API Key is missing. Please set VITE_YOUTUBE_API_KEY.");
      }

      const video = await searchVideo(frequency.query, API_KEY);
      if (video) {
        setVideoId(video.id.videoId);
        setIsPlaying(true);
      } else {
        setError('No video found for this frequency.');
      }
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to load video.');
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050511]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-[#050511] text-slate-200 selection:bg-indigo-500/30">
      {/* Background Gradients */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/20 rounded-full blur-[120px]" />
        <div className="absolute top-[20%] right-[-10%] w-[30%] h-[50%] bg-indigo-900/20 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[20%] w-[50%] h-[40%] bg-blue-900/10 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 container mx-auto px-6 py-12 min-h-screen flex flex-col max-w-7xl">
        <header className="mb-16 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-100 to-purple-100 tracking-tighter mb-2 drop-shadow-2xl">
              Mind Flow
            </h1>
            <p className="text-lg text-indigo-200 font-medium tracking-wide">
              Welcome back, <span className="text-white">{user.displayName || 'Traveler'}</span>
            </p>
          </div>

          <button
            onClick={logout}
            aria-label="Sign Out"
            className="group px-6 py-2.5 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 text-sm font-bold text-white hover:text-white transition-all duration-300 flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <span>Sign Out</span>
            <svg aria-hidden="true" className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
          </button>
        </header>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start" role="main">
          {/* Sidebar / Controls */}
          <nav aria-label="Frequency Selection" className="lg:col-span-4 space-y-6 lg:sticky lg:top-8 h-full overflow-y-auto max-h-[80vh] scrollbar-thin scrollbar-thumb-white/10 pr-2">
            <div className="flex items-center justify-between px-2 mb-2">
              <h2 className="text-xs font-bold text-indigo-300 uppercase tracking-[0.2em]">
                Select Frequency
              </h2>
              <div className="h-px w-12 bg-indigo-500/30"></div>
            </div>

            <div className="space-y-4">
              {FREQUENCIES.map((freq) => (
                <FrequencyButton
                  key={freq.id}
                  frequency={freq}
                  isActive={currentFrequency?.id === freq.id}
                  onClick={handleFrequencySelect}
                />
              ))}
            </div>
          </nav>

          {/* Main Content / Player */}
          <div className="lg:col-span-8 space-y-8">
            <div className="relative group w-full aspect-video rounded-3xl overflow-hidden shadow-2xl bg-black border border-white/10">
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/10 to-transparent pointer-events-none" />
              {isLoading ? (
                <div className="w-full h-full flex flex-col items-center justify-center bg-black">
                  <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mb-4"></div>
                  <div className="text-indigo-300 font-medium tracking-wide animate-pulse">Tuning Frequency...</div>
                </div>
              ) : (
                <Player
                  videoId={videoId}
                  isPlaying={isPlaying}
                  onStateChange={(e) => setIsPlaying(e.data === 1)}
                />
              )}
            </div>

            {currentFrequency && !isLoading && (
              <div className="relative overflow-hidden bg-gradient-to-br from-indigo-900/20 to-black/40 rounded-3xl p-10 border border-white/10 backdrop-blur-md">
                <div className="relative z-10">
                  <h2 className="text-4xl font-bold mb-2 text-white tracking-tight">
                    {currentFrequency.label}
                  </h2>
                  <div className="inline-block px-3 py-1 rounded-md bg-indigo-500/20 text-indigo-300 text-lg mb-6 font-mono border border-indigo-500/20">
                    {currentFrequency.hz}
                  </div>
                  <p className="text-slate-300 leading-8 text-lg font-light max-w-3xl">
                    {currentFrequency.description}
                  </p>
                </div>

                {/* Decorative Glow */}
                <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

                {error && (
                  <div className="mt-6 p-4 bg-red-500/5 border border-red-500/20 rounded-xl text-red-200 text-sm flex items-center gap-2">
                    <span className="text-red-500">⚠</span> {error}
                  </div>
                )}
              </div>
            )}

            {!API_KEY && (
              <div className="p-6 bg-amber-500/5 border border-amber-500/10 rounded-2xl text-amber-200 text-sm backdrop-blur-sm">
                <strong className="block mb-1 text-amber-400">Setup Required</strong>
                Please add your <code>VITE_YOUTUBE_API_KEY</code> to the <code>.env</code> file to enable video playback.
              </div>
            )}
          </div>
        </div>

        <footer className="mt-20 text-center border-t border-white/10 pt-8 pb-8">
          <p className="text-indigo-200/60 text-xs tracking-widest uppercase mb-4">© 2024 Mind Flow • Engineered for Focus</p>
          <div className="flex justify-center gap-6 text-xs text-indigo-300/80">
            <a href="#" className="hover:text-white transition-colors" aria-label="Privacy Policy">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors" aria-label="Terms of Service">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors" aria-label="Accessibility Statement">Accessibility</a>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
