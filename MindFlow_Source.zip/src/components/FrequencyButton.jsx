import React from 'react';

const FrequencyButton = ({ frequency, isActive, onClick }) => {
    return (
        <button
            onClick={() => onClick(frequency)}
            aria-pressed={isActive}
            role="tab"
            aria-selected={isActive}
            className={`
        group relative w-full overflow-hidden rounded-2xl p-6 text-left transition-all duration-500
        border backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-400
        ${isActive
                    ? 'bg-black/60 border-indigo-500/50 shadow-[0_0_30px_rgba(99,102,241,0.3)] scale-[1.02]'
                    : 'bg-black/40 border-white/10 hover:border-white/30 hover:bg-black/60 hover:shadow-2xl hover:shadow-indigo-500/10'
                }
      `}
        >
            {/* Active Glow Background */}
            {isActive && (
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-indigo-500/10 animate-pulse" />
            )}

            {/* Hover Shine Effect */}
            <div className={`
        absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent
        translate-x-[-100%] transition-transform duration-1000 group-hover:translate-x-[100%]
      `} />

            <div className="relative z-10">
                <div className="flex items-center justify-between mb-2">
                    <span className={`text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r ${isActive ? 'from-indigo-300 to-purple-300' : 'from-indigo-200 to-purple-200'} filter drop-shadow-lg`}>
                        {frequency.hz}
                    </span>
                    {isActive && (
                        <span className="flex h-3 w-3">
                            <span className="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-indigo-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
                        </span>
                    )}
                </div>

                <div className="text-sm font-bold text-white uppercase tracking-widest mb-2 shadow-black drop-shadow-sm">
                    {frequency.label}
                </div>

                <p className="text-sm text-gray-300 line-clamp-2 leading-relaxed font-normal mb-4 group-hover:text-white transition-colors">
                    {frequency.description}
                </p>

                <div className="flex flex-wrap gap-2">
                    {frequency.effects.map((effect, idx) => (
                        <span
                            key={idx}
                            className={`
                text-[10px] uppercase tracking-wider px-2 py-1 rounded-md border transition-colors font-medium
                ${isActive
                                    ? 'bg-indigo-500/30 border-indigo-400 text-indigo-100'
                                    : 'bg-white/10 border-white/20 text-white/70 group-hover:border-white/40 group-hover:text-white'
                                }
              `}
                        >
                            {effect}
                        </span>
                    ))}
                </div>
            </div>
        </button>
    );
};

export default FrequencyButton;
