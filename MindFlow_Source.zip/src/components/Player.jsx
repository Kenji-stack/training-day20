import React, { useRef, useEffect } from 'react';
import YouTube from 'react-youtube';

const Player = ({ videoId, isPlaying, onStateChange }) => {
    const playerRef = useRef(null);

    const opts = {
        height: '100%',
        width: '100%',
        playerVars: {
            autoplay: 1,
            controls: 1,
            modestbranding: 1,
            rel: 0,
        },
    };

    const onReady = (event) => {
        playerRef.current = event.target;
        if (isPlaying) {
            event.target.playVideo();
        }
    };

    useEffect(() => {
        if (playerRef.current) {
            if (isPlaying) {
                playerRef.current.playVideo();
            } else {
                playerRef.current.pauseVideo();
            }
        }
    }, [isPlaying]);

    if (!videoId) {
        return (
            <div className="w-full h-full flex items-center justify-center bg-black/40 rounded-3xl border border-white/10 backdrop-blur-sm">
                <div className="text-center p-8">
                    <div className="text-4xl mb-4">🎵</div>
                    <h3 className="text-xl font-medium text-white/80">Select a Frequency</h3>
                    <p className="text-white/40 mt-2 text-sm">Choose a frequency to start your session</p>
                </div>
            </div>
        );
    }

    return (
        <div className="relative w-full h-full overflow-hidden rounded-3xl shadow-2xl ring-1 ring-white/10 bg-black">
            <div className="absolute inset-0 z-0">
                <YouTube
                    videoId={videoId}
                    opts={opts}
                    onReady={onReady}
                    onStateChange={onStateChange}
                    className="h-full w-full"
                    iframeClassName="h-full w-full"
                />
            </div>
        </div>
    );
};

export default Player;
