import { initializeApp } from "firebase/app";
import {
    getAuth,
    GoogleAuthProvider,
    signInWithPopup,
    signOut,
    onAuthStateChanged
} from "firebase/auth";

const firebaseConfig = {
    apiKey: import.meta.env.VITE_YOUTUBE_API_KEY || "AIzaSyBQ6Op3aZm0AEFPgtah0n9E_1iwVvcoQ3U",
    authDomain: "tech-meetup-8a697.firebaseapp.com",
    projectId: "tech-meetup-8a697",
    storageBucket: "tech-meetup-8a697.appspot.com",
    messagingSenderId: "740852193816",
    appId: "1:740852193816:web:..." // We can guess this or leave it optional for Auth usually, but let's try to be safe.
    // Actually, Auth usually just needs apiKey and authDomain.
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const signInWithGoogle = async () => {
    try {
        const result = await signInWithPopup(auth, googleProvider);
        return result.user;
    } catch (error) {
        console.error("Error signing in with Google", error);
        throw error;
    }
};

export const logout = async () => {
    try {
        await signOut(auth);
    } catch (error) {
        console.error("Error signing out", error);
        throw error;
    }
};
