export const FREQUENCIES = [
  {
    id: '528hz',
    hz: '528Hz',
    label: 'Miracle Tone',
    effects: ['DNA Repair', 'Cellular Activation', 'Stress Reduction'],
    description: 'Known as the "Miracle" or "Love" frequency. Promotes healing and balance.',
    query: '528Hz healing music'
  },
  {
    id: '417hz',
    hz: '417Hz',
    label: 'Undoing Situations',
    effects: ['Clear Negativity', 'Facilitate Change', 'Mental Reboot'],
    description: 'Clears negative energy and facilitates conscious and subconscious change.',
    query: '417Hz solfeggio frequency'
  },
  {
    id: '963hz',
    hz: '963Hz',
    label: 'Frequency of Gods',
    effects: ['Awaken Intuition', 'Higher Consciousness', 'Clarity'],
    description: 'Connects with the light and all-encompassing spirit. Awaken your intuition.',
    query: '963Hz pineal gland activation'
  },
  {
    id: '432hz',
    hz: '432Hz',
    label: 'Natural Tuning',
    effects: ['Deep Healing', 'Water Harmonization', 'Right Brain Activation'],
    description: 'Resonates with the body’s natural frequency. Promotes deep peace and healing.',
    query: '432Hz deep healing music'
  },
  {
    id: 'alpha',
    hz: 'α Wave',
    label: 'Flow State',
    effects: ['Super Learning', 'Focus', 'Relaxed Concentration'],
    description: 'Induces the Alpha state (8-12Hz) for relaxed focus and "The Zone".',
    query: 'Alpha waves study music'
  },
  {
    id: 'theta',
    hz: 'θ Wave',
    label: 'Deep Meditation',
    effects: ['Memory Boost', 'Creativity', 'Deep Relaxation'],
    description: 'Theta state (4-8Hz) for deep meditation, creativity and memory retention.',
    query: 'Theta waves memory boost'
  }
];
