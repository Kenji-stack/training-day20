export const searchVideo = async (query, apiKey) => {
    if (!apiKey) {
        console.warn("No YouTube API Key provided");
        return null;
    }

    try {
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q=${encodeURIComponent(query)}&type=video&key=${apiKey}`
        );
        const data = await response.json();

        if (data.items && data.items.length > 0) {
            return data.items[0];
        }
        return null;
    } catch (error) {
        console.error("Error searching YouTube:", error);
        return null;
    }
};
