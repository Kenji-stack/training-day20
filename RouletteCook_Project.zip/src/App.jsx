import React, { useState, useEffect } from 'react';
import Roulette from './components/Roulette';
import RecipeCard from './components/RecipeCard';
import { RECIPE_CATEGORIES, fetchRecipe } from './services/rakutenApi';
import { Utensils, LogIn, LogOut, User } from 'lucide-react';
import { auth, provider } from './firebase';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';

function App() {
  const [currentRecipe, setCurrentRecipe] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Login failed", err);
      setError(`Login failed: ${err.message} (${err.code}). Please check "Authorized Domains" in Firebase Console.`);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCurrentRecipe(null); // Reset state on logout
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  const handleSpinEnd = async (category) => {
    setSelectedCategory(category);
    setLoading(true);
    setError(null);
    setCurrentRecipe(null);

    try {
      const recipe = await fetchRecipe(category.id);
      setCurrentRecipe(recipe);
      if (!recipe) {
        setError('No recipes found for this category.');
      }
    } catch (err) {
      setError('Failed to fetch recipe. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return <div className="app-container" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <div className="animate-pulse-slow">Loading...</div>
    </div>;
  }

  return (
    <div className="app-container">
      <header style={{ marginBottom: '2rem', display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative' }}>

        {user ? (
          <div style={{ position: 'absolute', top: 0, right: 0, display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName} style={{ width: '32px', height: '32px', borderRadius: '50%', border: '2px solid #00F5D4' }} />
              ) : (
                <User size={24} />
              )}
              <span style={{ fontSize: '0.9rem', color: '#ccc', display: 'none', md: 'block' }}>{user.displayName}</span>
            </div>
            <button
              onClick={handleLogout}
              style={{ background: 'transparent', border: '1px solid var(--glass-border)', color: '#fff', padding: '0.5rem', borderRadius: '50%', cursor: 'pointer' }}
              title="Sign Out"
              aria-label="ログアウト"
            >
              <LogOut size={18} />
            </button>
          </div>
        ) : null}

        <h1 className="text-gradient" style={{ fontSize: '3rem', margin: '0 0 1rem 0' }}>
          <Utensils style={{ marginRight: '1rem', verticalAlign: 'middle' }} size={48} />
          Roulette Cook
        </h1>
        <p style={{ fontSize: '1.2rem', color: '#a0a0a0' }}>
          Spin the wheel to decide your meal!
        </p>
      </header>

      <main>
        {!user ? (
          <div className="fade-in card" style={{ textAlign: 'center', maxWidth: '400px', margin: '0 auto' }}>
            <p style={{ marginBottom: '2rem' }}>Please sign in to start cooking.</p>
            <button
              onClick={handleLogin}
              className="btn-primary"
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', width: '100%' }}
            >
              <LogIn size={20} /> Sign in with Google
            </button>
          </div>
        ) : (
          <>
            {!currentRecipe && !loading && (
              <div className="fade-in">
                <Roulette
                  categories={RECIPE_CATEGORIES}
                  onSpinEnd={handleSpinEnd}
                />
              </div>
            )}

            {loading && (
              <div className="fade-in" style={{ margin: '2rem' }}>
                <div className="animate-pulse-slow" style={{ fontSize: '1.5rem', color: '#00F5D4' }}>
                  Finding the perfect {selectedCategory?.label} recipe...
                </div>
              </div>
            )}

            {error && (
              <div className="fade-in" style={{
                color: '#ff6b6b',
                background: 'rgba(255, 0, 0, 0.1)',
                padding: '1rem',
                borderRadius: '10px',
                margin: '1rem 0'
              }}>
                {error}
                <button
                  onClick={() => setError(null)}
                  style={{
                    display: 'block',
                    margin: '1rem auto 0',
                    background: 'transparent',
                    border: '1px solid #ff6b6b',
                    color: '#ff6b6b',
                    padding: '0.5rem 1rem',
                    borderRadius: '5px',
                    cursor: 'pointer'
                  }}
                >
                  Try Again
                </button>
              </div>
            )}

            {currentRecipe && (
              <div className="fade-in">
                <div style={{ marginBottom: '2rem' }}>
                  <h2 style={{ color: '#00F5D4' }}>Winner: {selectedCategory?.label}!</h2>
                </div>
                <RecipeCard recipe={currentRecipe} />
                <button
                  onClick={() => setCurrentRecipe(null)}
                  className="btn-primary"
                  style={{ marginTop: '2rem', padding: '0.8rem 2rem', fontSize: '1rem' }}
                >
                  Spin Again
                </button>
              </div>
            )}
          </>
        )}
      </main>

      <footer style={{ marginTop: '3rem', color: '#666', fontSize: '0.8rem' }}>
        Powered by Rakuten Recipe API
      </footer>
    </div>
  );
}

export default App;
