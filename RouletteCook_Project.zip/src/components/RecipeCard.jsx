import React from 'react';
import { ExternalLink, Clock, ChefHat } from 'lucide-react';

const RecipeCard = ({ recipe }) => {
    if (!recipe) return null;

    return (
        <div className="card fade-in" style={{ maxWidth: '400px', margin: '0 auto' }}>
            <div style={{ position: 'relative', borderRadius: '15px', overflow: 'hidden', marginBottom: '1rem' }}>
                <img
                    src={recipe.foodImageUrl}
                    alt={recipe.recipeTitle}
                    style={{ width: '100%', height: '250px', objectFit: 'cover' }}
                />
                <div style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    background: 'linear-gradient(to top, rgba(0,0,0,0.8), transparent)',
                    padding: '1rem',
                    color: 'white'
                }}>
                    <span style={{
                        background: '#FF5E62',
                        padding: '2px 8px',
                        borderRadius: '4px',
                        fontSize: '0.8rem',
                        fontWeight: 'bold'
                    }}>
                        {recipe.categoryName || 'Recipe'}
                    </span>
                </div>
            </div>

            <h2 style={{ fontSize: '1.5rem', margin: '0 0 0.5rem 0', lineHeight: 1.3 }}>
                {recipe.recipeTitle}
            </h2>

            <p style={{ color: '#ccc', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
                {recipe.recipeDescription}
            </p>

            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem', color: '#00F5D4' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                    <Clock size={18} />
                    <span>{recipe.recipeIndication || 'N/A'}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                    <ChefHat size={18} />
                    <span>Rakuten</span>
                </div>
            </div>

            <a
                href={recipe.recipeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary"
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '10px',
                    textDecoration: 'none',
                    width: '100%'
                }}
            >
                View Recipe <ExternalLink size={18} />
            </a>
        </div>
    );
};

export default RecipeCard;
