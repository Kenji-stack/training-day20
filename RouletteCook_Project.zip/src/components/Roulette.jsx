import React, { useState, useEffect } from 'react';
import './Roulette.css'; // We'll create this specific CSS

const Roulette = ({ categories, onSpinEnd }) => {
    const [rotation, setRotation] = useState(0);
    const [isSpinning, setIsSpinning] = useState(false);

    const spin = () => {
        if (isSpinning) return;

        setIsSpinning(true);

        // Calculate a random landing spot
        // 360 degrees
        // We want to spin at least 5 times (1800 deg) + random segment
        const segmentAngle = 360 / categories.length;
        const randomSegment = Math.floor(Math.random() * categories.length);

        // The pointer is usually at top (0 deg) or right.
        // Let's assume pointer is at Top (CSS transform origin center, 0 deg is usually 3 o'clock or 12 o'clock depending on setup).
        // If we rotate the wheel, the item at the top changes.
        // Target rotation:
        const extraSpins = 5 + Math.floor(Math.random() * 3); // 5-7 spins
        const targetRotation = rotation + (extraSpins * 360) + (Math.random() * 360);

        // We need to calculate which item lands at the pointer.
        // If we land at `targetRotation`, the normalized angle is `targetRotation % 360`.
        // We can back-calculate the item or just pass the `randomSegment` if we control the exact stop.
        // Let's control exact stop to the center of a segment for better UI.
        // Segment 0 center: 0 + half_segment?
        // Let's make it simpler:
        // Decide winner first.
        const winnerIndex = Math.floor(Math.random() * categories.length);
        // Angle to land on winner.
        // If winner is at index 0, we want index 0 to align with pointer.
        // If we rotate clockwise, the wheel moves.
        // If pointer is at Top (-90deg or 270deg visual), and index 0 is at 0deg initially.
        // To bring index 0 to Top, we rotate -90 or +270.
        // 
        // Let's simplify: Standard CSS rotation. 
        // Each segment covers `segmentAngle`.
        // Segment i starts at `i * segmentAngle`.
        // Center of segment i is `i * segmentAngle + segmentAngle / 2`.
        // To align Segment i center with Pointer (let's say Pointer is at 0 degrees - 12 o'clock),
        // We need to rotate the wheel such that `angle + center_i = 0` (or 360).
        // So rotation = - center_i.
        // Add multiple 360s.

        // Let's assume pointer is at top (270 degrees in CSS standard 0-is-right? No, let's stick to 0 is top if we position elements).
        // Actually, let's just rotate to a random large value and calculate winner from the angle.

        const finalRotation = rotation + 1800 + Math.random() * 360;
        setRotation(finalRotation);

        setTimeout(() => {
            setIsSpinning(false);
            // Calculate winner
            const normalizedRotation = finalRotation % 360;
            // If we rotate clockwise by `normalizedRotation`.
            // The segment that was at top (0) is now at `normalizedRotation`.
            // The segment that IS at top is the one that was at `-normalizedRotation`.
            // Angle coverage: 0 to 360.
            // (360 - normalizedRotation) % 360 is the angle on the wheel interacting with the pointer at 0.
            // Index = floor( angle / segmentAngle )
            const angleOnWheel = (360 - (normalizedRotation % 360)) % 360;
            // Adjust for segment offset if needed (if segment 0 is centered at 0 or starts at 0).
            // Assuming segment 0 starts at 0 (12 o'clock) and goes clockwise?
            // Actually usually easier to pre-determine winner and rotate to it.

            // Let's use the pre-determined winner approach to be precise.
            const winIdx = Math.floor(Math.random() * categories.length);
            const anglePerSegment = 360 / categories.length;
            // Target angle to put center of segment matching winIdx at top.
            // Segment i center: i * ans + ans/2.
            // We want this position to acturally be at 0 (or 270/etc).
            // Let's assume Top is 0.
            // requiredRotation = - (winIdx * anglePerSegment + anglePerSegment/2);
            // Make it positive and add spins.
            const targetAngleBase = (360 - (winIdx * anglePerSegment + anglePerSegment / 2));
            const newRotation = rotation + 360 * 5 + (targetAngleBase - (rotation % 360));

            // wait, `newRotation` needs to be > current `rotation`.
            // Current rotation % 360 might be anywhere.
            // We want to reach `targetAngleBase` (mod 360).
            // delta = targetAngleBase - (rotation % 360);
            // if delta < 0 delta += 360.
            // plus 5 full spins (1800).

            let delta = targetAngleBase - (rotation % 360);
            if (delta < 0) delta += 360;
            delta += 360 * 5;

            const finalRot = rotation + delta;

            setRotation(finalRot);

            // Delay callback to match animation duration
            setTimeout(() => {
                setIsSpinning(false);
                onSpinEnd(categories[winIdx]);
            }, 4000); // 4s animation

        }, 10);
    };

    // Actually the logic frame inside `spin` was trying 2 approaches. 
    // I will stick to: 
    // 1. Calculate random winner.
    // 2. Calculate required rotation.
    // 3. Animate.

    useEffect(() => {
        // Initial logic if needed
    }, []);

    return (
        <div className="roulette-container">
            <div className="pointer"></div>
            <div
                className="wheel"
                style={{
                    transform: `rotate(${rotation}deg)`,
                    transition: isSpinning ? 'transform 4s cubic-bezier(0.2, 0.8, 0.2, 1)' : 'none'
                }}
            >
                {categories.map((cat, index) => (
                    <div
                        key={index}
                        className="segment"
                        style={{
                            transform: `rotate(${index * (360 / categories.length)}deg) skewed?`,
                            // Styling segments is complex with just divs.
                            // Conic gradient is easier for background.
                        }}
                    >
                        {/* Text Label */}
                        <div className="label" style={{ transform: `rotate(${360 / categories.length / 2}deg)` }}>
                            {/* Text needs to be upright or radial? */}
                        </div>
                    </div>
                ))}
                {/* Simplified Wheel using Conic Gradient for colors and absolute positioned text */}
                <div
                    className="wheel-face"
                    style={{
                        background: `conic-gradient(
               ${categories.map((c, i) =>
                            `${i % 2 === 0 ? '#FF5E62' : '#FF9966'} ${i * (100 / categories.length)}% ${(i + 1) * (100 / categories.length)}%`
                        ).join(', ')}
             )`
                    }}
                >
                    {categories.map((cat, i) => (
                        <div
                            key={i}
                            className="wheel-text"
                            style={{
                                transform: `rotate(${i * (360 / categories.length) + (360 / categories.length) / 2}deg) translateY(-80px)`
                            }}
                        >
                            {cat.label}
                        </div>
                    ))}
                </div>
            </div>
            <button
                className="btn-primary spin-button"
                onClick={spin}
                disabled={isSpinning}
            >
                {isSpinning ? 'SPINNING...' : 'SPIN'}
            </button>
        </div>
    );
};

export default Roulette;
