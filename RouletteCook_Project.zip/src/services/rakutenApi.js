import fetchJsonp from 'fetch-jsonp';

const APP_ID = import.meta.env.VITE_RAKUTEN_APP_ID;
const BASE_URL = 'https://app.rakuten.co.jp/services/api/Recipe/CategoryRanking/20170426';

export const RECIPE_CATEGORIES = [
    { label: '和食', id: '30' },
    { label: '洋食', id: '31' },
    { label: '中華', id: '32' },
    { label: 'エスニック', id: '36' },
];

export const fetchRecipe = async (categoryId) => {
    if (!APP_ID) {
        throw new Error('Rakuten App ID is missing.');
    }

    try {
        const url = `${BASE_URL}?applicationId=${APP_ID}&categoryId=${categoryId}&format=json`;

        const response = await fetchJsonp(url);
        const data = await response.json();

        // Return a random recipe from the ranking
        const recipes = data.result;
        if (recipes && recipes.length > 0) {
            const randomIndex = Math.floor(Math.random() * recipes.length);
            return recipes[randomIndex];
        }
        return null;
    } catch (error) {
        console.error('Error fetching recipe:', error);
        throw error;
    }
};
